# SQL Sales Analysis Project

## Overview
This project analyzes sales data using SQL.

## Key Insights
- Total Sales and Profit calculated
- Category-wise and Region-wise analysis
- Top-performing products identified

## Tools Used
- MySQL / PostgreSQL

## Files
- queries.sql (contains table creation, data, and queries)
