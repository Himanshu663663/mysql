-- Create Table
CREATE TABLE sales (
Order_ID INT,
Date DATE,
Product VARCHAR(50),
Category VARCHAR(50),
Region VARCHAR(50),
Sales INT,
Profit INT,
Quantity INT
);

-- Insert Data
INSERT INTO sales VALUES
(1001,'2024-01-05','Laptop','Electronics','North',55000,5000,2),
(1002,'2024-01-07','Mobile','Electronics','South',20000,3000,3),
(1003,'2024-01-10','Chair','Furniture','West',8000,1200,4),
(1004,'2024-01-12','Table','Furniture','East',15000,2500,2),
(1005,'2024-01-15','Headphones','Electronics','North',3000,500,5);

-- Queries
-- Total Sales
SELECT SUM(Sales) AS Total_Sales FROM sales;

-- Total Profit
SELECT SUM(Profit) AS Total_Profit FROM sales;

-- Category-wise Sales
SELECT Category, SUM(Sales) AS Total_Sales
FROM sales
GROUP BY Category;

-- Region-wise Profit
SELECT Region, SUM(Profit) AS Total_Profit
FROM sales
GROUP BY Region;

-- Top Products
SELECT Product, SUM(Sales) AS Total_Sales
FROM sales
GROUP BY Product
ORDER BY Total_Sales DESC;
